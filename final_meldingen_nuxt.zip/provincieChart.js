export const provincieValue =[
    {provincie :'Noord-Brabant',total:0},
    {provincie: "Friesland",total: 0},
    {provincie: "Noord-Holland",total: 0},
    {provincie: "Zuid-Holland",total: 0},
    {provincie: "Zeeland",total: 0},
    {provincie: "Gelderland",total: 0},
    {provincie: "Utrecht",total: 0},
    {provincie: "Drenthe",total: 0},
    {provincie: "Groningen",total: 0},
    {provincie: "Overijssel",total: 0},
    {provincie: "Flevoland",total: 0},
    {provincie: "Limburg",total: 0},

]