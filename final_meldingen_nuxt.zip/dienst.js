export const dienstValue = [
    { dienst: "ambulance", total: 0 },
    { dienst: "brandweer", total: 0 },
    { dienst: "kustwacht", total: 0 },
    { dienst: "politie", total: 0 },
    { dienst: 'traumaheli', total: 0 },

]