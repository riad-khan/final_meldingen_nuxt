import type { NavigationGuard } from 'vue-router'
export type MiddlewareKey = string
declare module "C:/Users/riadk/Desktop/New folder/final_meldingen_nuxt/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    middleware?: MiddlewareKey | NavigationGuard | Array<MiddlewareKey | NavigationGuard>
  }
}